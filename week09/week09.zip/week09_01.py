class ReducedRowEchelonForm:
    pass

rref = ReducedRowEchelonForm()